import "./styles/tailwind.css";
import "./styles/github-markdown.css";
import "./styles/main.scss";
import "./styles/animate.css";
import "./libs/alpine";
import "./libs/overlayscrollbars";
import "./libs/color-scheme";
import { generateToc } from "./libs/toc";

window.generateToc = generateToc;
