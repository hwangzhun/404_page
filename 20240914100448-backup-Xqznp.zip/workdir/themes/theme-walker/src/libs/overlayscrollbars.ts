import "overlayscrollbars/overlayscrollbars.css";
import { OverlayScrollbars, ScrollbarsHidingPlugin, SizeObserverPlugin, ClickScrollPlugin } from "overlayscrollbars";

OverlayScrollbars.plugin(ScrollbarsHidingPlugin);
OverlayScrollbars.plugin(SizeObserverPlugin);
OverlayScrollbars.plugin(ClickScrollPlugin);

document.addEventListener("DOMContentLoaded", () => {
  ["body", ".sidebar-content"].forEach(createInstance);
});

function createInstance(selector: string) {
  const dom = document.querySelector(selector) as HTMLElement;
  if (dom) {
    const instance = OverlayScrollbars(dom, {
      scrollbars: {
        autoHide: "scroll",
        autoHideDelay: 600,
      },
    });
    instance.on("updated", () => {
      dom.classList.remove("hidden");
    });
  }
}
