import { activeColorScheme, getSystemColorScheme, applyColorScheme, enableViewTransitionApi } from "../color-scheme";

export default () => ({
  checked: false,
  init() {
    this.checked = activeColorScheme === "system" ? getSystemColorScheme() === "dark" : activeColorScheme === "dark";

    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
      if (activeColorScheme === "system") {
        this.checked = getSystemColorScheme() === "dark";
      }
    });
  },
  handleChange(event: PointerEvent) {
    const newScheme = this.checked ? "light" : "dark";

    const isAppearanceTransition =
      // @ts-expect-error: Transition API
      document.startViewTransition &&
      !window.matchMedia(`(prefers-reduced-motion: reduce)`).matches &&
      enableViewTransitionApi;

    if (!isAppearanceTransition) {
      applyColorScheme(newScheme, true);
      this.checked = !this.checked;
      return;
    }

    const x = event.clientX;
    const y = event.clientY;
    const endRadius = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));

    this.checked = !this.checked;
    // @ts-expect-error: Transition API
    const transition = document.startViewTransition(() => {
      applyColorScheme(newScheme, true);
    });

    transition.ready.then(() => {
      const clipPath = [`circle(0px at ${x}px ${y}px)`, `circle(${endRadius}px at ${x}px ${y}px)`];

      document.documentElement.animate(
        {
          clipPath: newScheme === "dark" ? clipPath : [...clipPath].reverse(),
        },
        {
          duration: 350,
          easing: "ease-in",
          pseudoElement: newScheme === "dark" ? "::view-transition-new(root)" : "::view-transition-old(root)",
        }
      );
    });
  },
});
