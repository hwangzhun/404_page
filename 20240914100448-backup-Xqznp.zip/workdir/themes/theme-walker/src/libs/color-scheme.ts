type ColorSchemeType = "system" | "dark" | "light";

export let activeColorScheme: ColorSchemeType = "system";
export let currentDefaultLight = "light";
export let currentDefaultDark = "dark";
export let enableViewTransitionApi = true;

export function initColorScheme(
  defaultColorScheme: ColorSchemeType,
  defaultLight: string,
  defaultDark: string,
  enableChangeColorScheme: boolean,
  _enableViewTransitionApi: boolean
) {
  activeColorScheme =
    (enableChangeColorScheme && (localStorage.getItem("color-scheme") as ColorSchemeType)) || defaultColorScheme;
  currentDefaultLight = defaultLight;
  currentDefaultDark = defaultDark;
  enableViewTransitionApi = _enableViewTransitionApi;

  applyColorScheme(activeColorScheme, enableChangeColorScheme);
}

export function applyColorScheme(colorScheme: ColorSchemeType, store: boolean) {
  const actualColorScheme = colorScheme === "system" ? getSystemColorScheme() : colorScheme;
  const theme = actualColorScheme === "dark" ? currentDefaultDark : currentDefaultLight;

  document.documentElement.dataset.theme = theme;
  document.documentElement.dataset.colorScheme = colorScheme === "system" ? getSystemColorScheme() : colorScheme;
  if (store) {
    localStorage.setItem("color-scheme", colorScheme);
  }
}

export function getSystemColorScheme(): ColorSchemeType {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
  if (activeColorScheme === "system") {
    applyColorScheme("system", false);
  }
});

declare global {
  interface Window {
    initColorScheme: typeof initColorScheme;
    applyColorScheme: typeof applyColorScheme;
  }
}

window.initColorScheme = initColorScheme;
window.applyColorScheme = applyColorScheme;
