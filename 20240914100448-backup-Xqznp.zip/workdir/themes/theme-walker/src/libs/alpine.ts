import Alpine from "alpinejs";
import upvote from "./alpine-data/upvote";
import share from "./alpine-data/share";
import colorSchemeSwitcher from "./alpine-data/color-scheme-switcher";
import subMenu from "./alpine-data/sub-menu";
import menu from "./alpine-data/menu";

window.Alpine = Alpine;

Alpine.data("app", () => ({
  menuVisible: false,
  openMenu: function () {
    this.menuVisible = true;
  },
  closeMenu: function () {
    this.menuVisible = false;
  },
}));

// @ts-ignore
Alpine.data("upvote", upvote);
// @ts-ignore
Alpine.data("share", share);
Alpine.data("colorSchemeSwitcher", colorSchemeSwitcher);
// @ts-ignore
Alpine.data("menu", menu);
Alpine.data("subMenu", subMenu);

Alpine.start();
