/** @type {import('tailwindcss').Config} */
const { Icons } = require("tailwindcss-plugin-icons");
module.exports = {
  content: ["./templates/**/*.html", "./src/**/*.ts"],
  darkMode: "class",
  plugins: [
    require("@tailwindcss/typography"),
    require("@tailwindcss/aspect-ratio"),
    Icons(() => ({
      ri: {
        includeAll: true,
      },
      simpleIcons: {
        includeAll: true,
      },
      tabler: {
        includeAll: true,
      },
    })),
    require("daisyui"),
  ],
  daisyui: {
    themes: true,
  },
  safelist: [
    "i-ri-mail-line",
    "i-ri-wechat-2-line",
    "i-ri-qq-line",
    "i-ri-weibo-fill",
    "i-ri-zhihu-line",
    "i-ri-douban-line",
    "i-ri-bilibili-line",
    "i-ri-tiktok-line",
    "i-ri-telegram-fill",
    "i-ri-facebook-box-line",
    "i-ri-instagram-line",
    "i-ri-linkedin-box-line",
    "i-ri-twitter-line",
    "i-ri-slack-fill",
    "i-ri-discord-line",
    "i-ri-youtube-line",
    "i-ri-steam-fill",
    "i-ri-github-fill",
    "i-ri-gitlab-line",
    "i-ri-rss-fill",
    "i-simple-icons-matrix",
  ],
};
