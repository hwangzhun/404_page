# Walker

Walker 是一款漂亮、简洁、优雅的 Halo 主题，非常适合用来搭建个人博客。

![Walker](./images/theme-walker-home-2.png)

> Walker 最初是由 [EryouHao](https://github.com/EryouHao) 为 [Gridea](https://gridea.dev/) 开发的主题，经过作者授权后，我们将其移植到了 Halo 平台上，并添加了一些适用于 Halo 平台特性的功能。需要注意，此主题目前由 Halo 团队维护，如有问题可以在[讨论](https://halo.run/store/apps/app-GHgAR?tab=comment)中反馈。

## 特性

1. 简约美观的风格，但几乎包含 Halo 的所有特性。
2. 支持切换配色，并内置 32 套配色。
3. 支持 Halo 内部的所有页面，包括文章、页面、分类、标签、归档、作者页等。
4. 支持 Halo 官网所有的页面内容管理插件，包括友情链接、图库、瞬间。
5. 优秀的性能，主题本身仅包含一个 CSS 文件和一个 JS 文件，gzip 压缩后仅有 40KB 左右。
6. 支持 [Open Graph](https://ogp.me/)。

## 预览

- <https://ryanc.cc>
- <https://demo.halo.run/?preview-theme=theme-walker>

> <https://demo.halo.run> 下的演示可以根据[在线体验](https://docs.halo.run/#%E5%9C%A8%E7%BA%BF%E4%BD%93%E9%AA%8C)进入 Console 之后实际操作。
> 此外，如果你想将你的网站放在这里，可以在[讨论](https://halo.run/store/apps/app-GHgAR?tab=comment)中留言。

## 使用方式

1. 下载，前往[版本](https://halo.run/store/apps/app-GHgAR?tab=releases)页面安装最新的版本即可，后续有更新也会在此页面发布。
2. 安装和更新方式可参考：<https://docs.halo.run/user-guide/themes>

## 插件支持

Walker 主题支持以下 Halo 插件：

- 友情链接（/links）：<https://halo.run/store/apps/app-hfbQg>
- 图库（/photos）：<https://halo.run/store/apps/app-BmQJW>
- 瞬间（/moments）：<https://halo.run/store/apps/app-SnwWD>

为了获得更好的体验，你还可以安装以下插件（如果需要）：

- highlight.js 代码高亮：<https://halo.run/store/apps/app-sqpgf>
- lightgallery.js 灯箱：<https://halo.run/store/apps/app-OoggD>

## FAQ

### 在低版本浏览器中，无法切换配色

目前 Walker 的配色切换方案使用了 [daisyUI](https://daisyui.com) CSS 框架，但此框架的配色方案无法在低版本浏览器中正常工作。详情可查阅：<https://github.com/saadeghi/daisyui/issues/2703>

> 浏览器兼容情况可查阅：<https://caniuse.com/mdn-css_types_color_oklch>

### 如何在瞬间和相册页面支持图片灯箱？

安装 [lightgallery.js 灯箱](https://halo.run/store/apps/app-OoggD) 插件的最新版本，然后进入插件设置，配置以下**页面匹配规则**：

| 路径匹配 | 匹配区域 |
| --- | --- |
| `/moments*` | `.markdown-body` |
| `/moments*` | `.moment-media` |
| `/photos*` | `#photos` |

### 如何在瞬间页面支持代码高亮？

安装 [highlight.js 代码高亮](https://www.halo.run/store/apps/app-sqpgf) 插件的最新版本，然后进入插件设置，配置以下**页面匹配规则**：

1. `/moments`
2. `/moments/**`

### 如何让友情链接页面支持评论？

目前 [链接管理](https://www.halo.run/store/apps/app-hfbQg) 插件提供的默认路由（/links）暂不支持评论组件的接入，但此主题为页面提供了单独的模板（page-links.html）来利用页面的评论功能。只需要新建一个页面然后在设置中的 **自定义模板** 选项选择 **友情链接** 即可，然后用这个页面作为友情链接的页面。但需要注意的是，页面别名不能和链接管理插件提供的（/links）一致。

### 如何在菜单项中添加图标？

目前 Walker 为菜单项元数据添加了图标的设置项，你可以在 Halo 的菜单管理中为需要的菜单项设置图标。推荐在 <https://icones.js.org/> 中选择同一套图标包，下载 svg 上传到 Halo 进行使用。
